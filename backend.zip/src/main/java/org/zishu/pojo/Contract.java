package org.zishu.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Blank
 * @version 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Contract {
    private Long contractId;//合同id
    private Long clientId;//客户id
    private Long houseId;//房源id
    private Long managerId;//经纪人id
    private Long totalAmount;//总金额
    private String paymentPlan;//付款计划
    private LocalDateTime signTime;//签约时间
    private String status;//状态
    private String contractFile;//合同文件
}
