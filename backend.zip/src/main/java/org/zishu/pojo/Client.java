package org.zishu.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Client {
    private Long clientId;// 客户ID
    private String name;// 客户姓名
    private String username;// 用户名
    private String password;// 密码
    private String phone;// 手机号
    private String email;// 邮箱
    private BigDecimal budgetMin;// 预算最小值
    private BigDecimal budgetMax;// 预算最大值
    private Map<String, String> preference; // 可以使用 JSON 类型存储为字符串，也可以映射为 Map 等类型
    private LocalDateTime createdAt;// 创建时间

}
