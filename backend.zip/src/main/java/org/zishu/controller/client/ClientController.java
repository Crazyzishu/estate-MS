package org.zishu.controller.client;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zishu.pojo.Client;
import org.zishu.pojo.Result;
import org.zishu.service.client.ClientService;

@Slf4j
@RestController
@RequestMapping("/api/clients")
public class ClientController {
    @Autowired
    private ClientService clientService;

    /**
     * 客户信息录入
     */
    @PostMapping
    public Result save(@RequestBody Client client) {
        log.info("客户信息录入:{}", client);
        clientService.save(client);
        return Result.success();
    }
}
