package org.zishu.controller.manager;

public class HouseController {
}
