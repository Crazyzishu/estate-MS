package org.zishu.service.manager;

public interface testService {
}
