package org.zishu.service.manager;

public class testServiceImpl {
}
