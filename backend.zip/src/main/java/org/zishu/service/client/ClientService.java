package org.zishu.service.client;

import org.zishu.pojo.Client;

public interface ClientService {
    /**
     * 客户信息录入
     * @param client
     */
    void save(Client client);
}
