package org.zishu.service.client.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zishu.mapper.ClientMapper;
import org.zishu.pojo.Client;
import org.zishu.service.client.ClientService;

@Service
public class ClientServiceImpl implements ClientService {

    @Autowired
    private ClientMapper clientMapper;

    @Override
    public void save(Client client) {
        clientMapper.insert(client);
    }
}
