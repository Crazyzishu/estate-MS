package org.zishu.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.zishu.pojo.Client;

/**
 * @author Blank
 * @version 1.0
 */
@Mapper
public interface ClientMapper {

    void insert(Client client);
}
